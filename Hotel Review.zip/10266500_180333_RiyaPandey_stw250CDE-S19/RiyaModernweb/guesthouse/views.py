from django.shortcuts import render
from rooms.models import Room
# from crud.models import Post
# from products.models import Product


def show_home(request):
    data = Room.objects.all()
    send = {
        "all_data": data
    }
    return render(request, 'index.html',send)
    # products = Product.objects.all().order_by('-id')[:4]
    # posts = Post.objects.all().order_by('-id')[:3]
    