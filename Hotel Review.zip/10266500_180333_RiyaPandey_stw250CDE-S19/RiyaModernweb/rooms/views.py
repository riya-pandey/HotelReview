from django.shortcuts import render,redirect

from reviews.models import Review
from rooms.models import Room

# Create your views here.
def list_house(request):
    data = Room.objects.all()
    send = {
        "all_data": data
    }
    return render(request, 'room.html',send)
    

def view_house(request, id):
    if request.method == 'POST':
        user = request.user
        room = Room(id=id)
        comment = request.POST['comment']
        r = Review(user_id=user, guest_house_id=room, comment=comment)
        r.save()

    comments = Review.objects.filter(guest_house_id=id)

    data = Room.objects.get(id=id)
    send = {
        "all_data": data,
        "all_comment": comments
    }
    return render(request, 'review.html', send)

