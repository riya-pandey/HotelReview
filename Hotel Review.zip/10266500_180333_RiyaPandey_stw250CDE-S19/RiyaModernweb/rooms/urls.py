from django.urls import path
from rooms import views


urlpatterns = [
    path('', views.list_house),
    path('<id>', views.view_house),
    # path('register/',views.register)
]