from django.contrib import admin
from rooms.models import Room


class Roomadmin(admin.ModelAdmin):
    list_display = ('name','description','image','location')
admin.site.register(Room,Roomadmin)