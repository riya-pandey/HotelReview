# guesthouse
It is a small CRUD app made using Django for college project
