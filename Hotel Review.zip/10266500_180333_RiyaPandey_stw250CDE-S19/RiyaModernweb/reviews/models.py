from django.contrib.auth.models import User
from django.db import models
from rooms.models import Room


class Review(models.Model):
    user_id = models.ForeignKey(User, on_delete=models.CASCADE)
    guest_house_id = models.ForeignKey(Room, on_delete=models.CASCADE)
    comment = models.TextField()
