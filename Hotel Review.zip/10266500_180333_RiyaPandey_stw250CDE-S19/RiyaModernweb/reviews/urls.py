from django.urls import path

from reviews import views

urlpatterns = [
     path('', views.show_comment),
     path('add', views.add_comment),
     path('update/<id>', views.update_comment),
     path('delete/<id>', views.delete_comment),
]