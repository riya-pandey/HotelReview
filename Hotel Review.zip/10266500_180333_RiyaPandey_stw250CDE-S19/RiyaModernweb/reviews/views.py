from django.shortcuts import render, redirect
from reviews.models import Review

def add_comment(request):
    return render(request, 'review.html', {'message': 'Error! Please login to comment'})

    return render(request, 'review.html')
    return render(request, 'review.html')


def update_comment(request):
    return render(request, 'review.html')





def delete_comment(request,id):
    if request.user.is_authenticated:
        review = Review(id=id)
        review.delete()
        return redirect('/')
    else:
        return redirect(request,'review.html', {'message': 'Error! Please login to delete'})
    return render(request, 'review.html')


def show_comment(request):
    if request.method == 'POST':
        if request.user.is_authenticated:
            # comment=request.POST['comment']
            # user_id =request.user.id
            # name = request.user.username
            # guesthouseID
            # save_task = Review.objects.create(first_name=fn, last_name=ln, email=em, username=un, password=pw)
            # user.save()
            return redirect('/user/login')
        else:
            return render(request, 'review.html', {'message': 'Error! Please login to comment'})

    return render(request, 'review.html')
