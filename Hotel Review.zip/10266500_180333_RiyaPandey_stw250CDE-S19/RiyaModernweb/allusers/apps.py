from django.apps import AppConfig


class AllusersConfig(AppConfig):
    name = 'allusers'
