from django.shortcuts import render, redirect
from django.contrib.auth.models import User
from django.contrib import auth


# Create your views here.
def show_register(request):
    if request.method == 'POST':
        fn=request.POST['fn']
        ln=request.POST['ln']
        em=request.POST['em']
        un=request.POST['un']
        pw=request.POST['pw']
        user = User.objects.create_user(first_name=fn, last_name=ln, email=em, username=un, password=pw)
        user.save()
        return redirect ('/user/login')

    return render(request, 'register.html')


def show_login(request):
    if request.method =='POST':
        un = request.POST['un']
        pw = request.POST['pw']
        user = auth.authenticate(username=un, password=pw)
        if user is not None:
            auth.login(request, user)
            return redirect('/guest-house')

    return render(request, 'login.html')


def show_dashboard(request):
    return render(request, 'room.html')


def do_logout(request):
    auth.logout(request)
    return redirect('/guest-house')